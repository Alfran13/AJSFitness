<?php

namespace App\Controller;
use  App\Controller\AppController;
class TestController extends AppController
{
	public function index()
	{
		
	}

	public function owt()
{
	//$this->autoRender=false;
	//echo "<h4>wassup niggaaa</h4>";
}

}





?>